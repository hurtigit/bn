---
title: "Belysningen på Rinna motionsspår är igång"
excerpt: "Nu kan du springa och gå säkert även när mörkret faller. Belysningen på det populära motionsspåret är äntligen inkopplad."
date: 2025-09-25
author: "Redaktionen"
category: "fritid"
image: "https://images.unsplash.com/photo-1476480862126-209bfaa8edc8?w=800&h=500&fit=crop"
imageAlt: "Upplyst motionsspår i skogen"
featured: false
---

Från och med idag är belysningen på Rinna motionsspår inkopplad och igång. Det innebär att motionärer nu kan använda spåret säkert även under de mörka höst- och vintermånaderna.

## Efterlängtat projekt

Belysningsprojektet har varit efterlängtat av många boende i kommunen.

"Vi har fått många önskemål om belysning längs spåret och är glada att äntligen kunna erbjuda detta", säger fritidschefen.

## Energieffektiv lösning

Den nya belysningen är helt LED-baserad och styrs av rörelsedetektorer för att spara energi. Lamporna tänds automatiskt när det börjar skymma och släcks vid midnatt.

## Ökad trygghet

Förutom att möjliggöra motion under mörka timmar förväntas belysningen också öka tryggheten längs spåret.
