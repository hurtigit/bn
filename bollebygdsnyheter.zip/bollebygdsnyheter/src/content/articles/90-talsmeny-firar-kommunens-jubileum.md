---
title: "90-talsmeny firar kommunens 30-årsjubileum"
excerpt: "Under vecka 41 blir det nostalgi i matsalen för alla barn och ungdomar i förskola och skola i kommunen."
date: 2025-10-02
author: "Erik Svensson"
category: "kommun"
image: "https://images.unsplash.com/photo-1567521464027-f127ff144326?w=800&h=500&fit=crop"
imageAlt: "Skolmatsal med elever"
featured: false
---

Måltidsverksamheten uppmärksammar kommunens 30-årsjubileum genom att servera en lunchmeny som hyllar några av 90-talets mest uppskattade rätter.

## Nostalgisk meny

På menyn finns klassiker som:

- Flygande Jakob
- Korvstroganoff
- Pannbiff med lök
- Ärtsoppa med pannkakor

"Vi ville göra något roligt för att fira jubileet och tänkte att maten från 90-talet skulle väcka minnen hos både personal och föräldrar", berättar måltidschefen.

## Eleverna nyfikna

Många elever har aldrig smakat rätterna tidigare och är nyfikna på vad som väntar.

"Jag har hört mamma prata om flygande Jakob men aldrig ätit det. Det blir spännande!", säger en elev i årskurs 5.
