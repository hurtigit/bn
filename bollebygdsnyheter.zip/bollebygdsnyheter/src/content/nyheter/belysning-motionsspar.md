---
title: "Ny belysning på Rinna motionsspår"
description: "Nu är den efterlängtade belysningen på plats och motionsspåret kan användas även under mörka kvällar."
date: "2025-12-28"
category: "Nyheter"
image: "/images/motionsspar.jpg"
author: "Anna Svensson"
featured: false
---

Äntligen! Den nya belysningen på Rinna motionsspår är nu inkopplad och igång. Det betyder att motionärer kan njuta av spåret även under de mörka vintermånaderna.

## Efterlängtat projekt

Projektet har varit planerat länge och många Bollebygdsbor har väntat otåligt på att kunna springa eller promenera i spåret efter jobbet.

– Det känns fantastiskt att äntligen kunna erbjuda våra invånare ett säkert och välbelyst motionsspår året runt, säger fritidschefen.

Belysningen är energieffektiv LED-teknik som tänds automatiskt när det blir mörkt.
