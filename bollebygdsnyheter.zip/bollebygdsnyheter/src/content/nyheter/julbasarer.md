---
title: "Julbasarer hålls vid liv av ideella krafter"
description: "En liten men engagerad grupp ser till att jultraditionen lever vidare i bygden."
date: "2025-12-20"
category: "Evenemang"
image: "/images/julbasar.jpg"
author: "Maria Lindqvist"
featured: false
---

Varje år samlas en grupp engagerade Bollebygdsbor för att arrangera julbasarer runt om i kommunen. Det är en tradition som sträcker sig långt tillbaka i tiden.

## Ideellt engagemang

– Vi gör det för att vi älskar traditionen och för att det samlar bygden, berättar Karin, en av de drivande krafterna bakom arrangemanget.

Gruppen vill gärna bli fler och välkomnar alla som vill hjälpa till med nästa års basarer.

## Program för årets basarer

Basarerna bjuder på:

- Hembakat fika och kaffe
- Hantverk och julpynt
- Lotterier med fina vinster
- Tomtebesök för barnen
- Körsång och jullåtar

Intäkterna går till lokala föreningar och välgörande ändamål.
