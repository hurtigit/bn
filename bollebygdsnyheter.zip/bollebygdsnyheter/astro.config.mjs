import { defineConfig } from 'astro/config';
import sitemap from '@astrojs/sitemap';

// https://astro.build/config
export default defineConfig({
  site: 'https://yourusername.github.io',
  base: '/bollebygdsnyheter',
  integrations: [sitemap()],
  output: 'static',
  build: {
    assets: 'assets'
  }
});
